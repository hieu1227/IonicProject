import {  IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonGrid, IonRow, IonCol, IonItem, IonLabel, IonSelect, IonSelectOption, IonInput, IonDatetime, IonRadioGroup, IonRadio, IonTextarea,IonButton, IonIcon, IonToast,} from '@ionic/react';
import { useState } from 'react';
import { useHistory } from 'react-router';
import { addCircle } from 'ionicons/icons';
import { insertApartment } from '../databaseHandler';
  
  
  
  const Create: React.FC = () => {
    // Property type
    const [propertyType, setPropertyType] = useState('');
    const [bedrooms, setBedrooms] = useState('');
    const [dateTimeAdding, setDateTimeAdding] = useState('');
    const [monthlyRentPrice, setMonthlyRentPrice] = useState('');
    const [furnitureTypes, setFurnitureTypes] = useState('');
    const [notes, setNotes] = useState('');
    const [nameReporter, setNameReporter] = useState('');
    const [showToast, setShowToast] = useState(false);
    const [headerMessage, setHeaderMessage] = useState('');
    const [message, setMessage] = useState('');
    const [colorMessage, setColorMessage] = useState('');
    const history = useHistory();
  
    
      /**
       * Function handle Submit Form
       */
      const handleSubmit = async() => {
        const Form = {
          propertyType,
          bedrooms,
          dateTimeAdding: dateTimeAdding,
          monthlyRentPrice,
          furnitureTypes,
          notes,
          nameReporter,
        };
    
        if (Form.propertyType.length === 0) {
          setHeaderMessage('Warning');
          setMessage('Enter the Property type !');
          setColorMessage('danger');
          setShowToast(true);
          setTimeout(()=>{
            setShowToast(false);
          }, 5000)
          
          } else if (Form.bedrooms.length === 0) {
            setHeaderMessage('Warning');
            setMessage('Enter the Bedrooms !');
            setColorMessage('danger');
            setShowToast(true);
            setTimeout(()=>{
                setShowToast(false);
            }, 5000)
          
          } else if (Form.dateTimeAdding.length === 0) {
            setHeaderMessage('Warning');
            setMessage('Select Date of the added property !');
            setColorMessage('danger');
            setShowToast(true);
            setTimeout(()=>{
              setShowToast(false);
            }, 5000)
            
            }  else if (Form.monthlyRentPrice.length === 0) {
              setHeaderMessage('Warning');
              setMessage('Enter the Monthly rent price!');
              setColorMessage('danger');
              setShowToast(true);
              setTimeout(()=>{
                setShowToast(false);
              }, 5000)
            
            } else if (Form.nameReporter.length === 0) {
              setHeaderMessage('Warning');
              setMessage(`Enter Reporter's Name !`);
              setColorMessage('danger');
              setShowToast(true);
              setTimeout(()=>{
                setShowToast(false);
              }, 5000)
            
            } else {
              setHeaderMessage('Success');      
              setMessage('Successful submission');         
              setColorMessage('success');
              setShowToast(true);
              await insertApartment(Form);    
              setTimeout(()=>{        
                setShowToast(false);
                history.goBack();       
              }, 3000)
            
            }
            
            };
  
    return (
      <IonPage>
  
        {/* Header */}
        <IonHeader>
          <IonToolbar>
            <IonTitle>Create an apartment</IonTitle>
          </IonToolbar>
        </IonHeader>
  
        {/* Content */}
        <IonContent fullscreen>
          <IonGrid>
  
            {/* Select Property type */}
            <IonRow>
              <IonCol>
                <IonLabel position="stacked">Property type</IonLabel>
                <IonSelect
                  value={propertyType}
                  onIonChange={event => setPropertyType(event.detail.value)}
                  placeholder="Select property type"
                >
                  <IonSelectOption value="Flat">Flat</IonSelectOption>
                  <IonSelectOption value="House">House</IonSelectOption>
                  <IonSelectOption value="Bungalow">Bungalow</IonSelectOption>
                </IonSelect>
              </IonCol>
            </IonRow>
  
            {/* Number Bedrooms */}
            <IonRow>
              <IonCol>
                <IonLabel position="stacked">Bedrooms</IonLabel>
                <IonInput type='number'
                  onIonChange={event => setBedrooms(event.detail.value!)}
                  placeholder="Enter the number of bedrooms"
                ></IonInput>
              </IonCol>
            </IonRow>
  
            {/* Date and time of adding the Property */}
            <IonRow>
              <IonCol>
                <IonLabel position="stacked">
                  Date and time of adding the Property
                </IonLabel>
                <IonDatetime
                  onIonChange={event => setDateTimeAdding(event.detail.value!)} 
                  display-format="YYYY/MM/DD" 
                  placeholder="Select date and time"
                ></IonDatetime>
              </IonCol>
            </IonRow>
  
            {/* Monthly rent price */}
            <IonRow>
              <IonCol>
                <IonLabel position="stacked">Monthly rent price</IonLabel>
                <IonInput type='number'
                  onIonChange={event => setMonthlyRentPrice(event.detail.value!)} 
                  placeholder="Enter monthly rent price"
                ></IonInput>
              </IonCol>
            </IonRow>
  
            {/* Furniture types */}
            <IonRow>
              <IonCol>
                <IonLabel position="stacked">Furniture types</IonLabel>
                <IonRadioGroup 
                  onIonChange={event => setFurnitureTypes(event.detail.value)} 
                  style={{ marginTop: '10px' }}
                >
                  <IonItem>
                    <IonLabel><small>Furnished</small></IonLabel>
                    <IonRadio slot="start" value="Furnished"></IonRadio>
                  </IonItem>
                  <IonItem>
                    <IonLabel><small>Unfurnished</small></IonLabel>
                    <IonRadio slot="start" value="Unfurnished"></IonRadio>
                  </IonItem>
                  <IonItem>
                    <IonLabel><small>Part Furnished</small></IonLabel>
                    <IonRadio slot="start" value="PartFurnished"></IonRadio>
                  </IonItem>
                </IonRadioGroup>
              </IonCol>
            </IonRow>
  
            {/* Notes */}
            <IonRow>
              <IonCol>
                <IonLabel position="stacked">Notes</IonLabel>
                <IonTextarea
                  onIonChange={event => setNotes(event.detail.value!)}
                  placeholder="Enter Notes"
                ></IonTextarea>
              </IonCol>
            </IonRow>
  
            {/* Name of the reporter */}
            <IonRow>
              <IonCol>
                <IonLabel position="stacked">Name of the reporter</IonLabel>
                <IonInput
                  onIonChange={event => setNameReporter(event.detail.value!)} 
                  placeholder="Enter name of the reporter"
                ></IonInput>
              </IonCol>
            </IonRow>

            {/* Button Submit */}
            <IonRow>
              <IonCol>
                <IonButton size="small" expand="block" onClick={handleSubmit}>
                  <IonIcon slot="icon-only" icon={addCircle}></IonIcon>Submit
                </IonButton>
              </IonCol>
            </IonRow>
  
          </IonGrid>
        </IonContent>
  
        {/* Start Toast */}
        <IonToast 
          isOpen={showToast} 
          header={headerMessage} 
          message={message} 
          color={colorMessage} 
          position="top"
        ></IonToast>
        {/* End Toast */}
  
      </IonPage>
    );
  };
  
  export default Create;