import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonItem, IonLabel, IonSelect, IonSelectOption, IonInput, IonDatetime, IonRadioGroup, IonRadio, IonTextarea, IonButton, IonIcon, IonToast } from '@ionic/react';
import './Home.css';
import {useState} from 'react';
import {add} from 'ionicons/icons'




const Home: React.FC = () => {
  // Property type
  const [propertyType, setPropertyType] = useState('');
  const [bedrooms, setBedrooms] = useState('');
  const [dateTimeAdding, setDateTimeAdding] = useState('');
  const [monthlyRentPrice, setMonthlyRentPrice] = useState('');
  const [furnitureTypes, setFurnitureTypes] = useState('');
  const [notes, setNotes] = useState('');
  const [nameReporter, setNameReporter] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [headerMessage, setHeaderMessage] = useState('');
  const [message, setMessage] = useState('');
  const [colorMessage, setColorMessage] = useState('');

  /**
   * Function handle Submit Form
   */
  const handleSubmit = () => {
    const Form = {
      propertyType,
      bedrooms,
      dateTimeAdding: dateTimeAdding,
      monthlyRentPrice,
      furnitureTypes,
      notes,
      nameReporter,
    };

    if (Form.propertyType.length === 0) {
      setHeaderMessage('Warning');
      setMessage('Enter the Property type !');
      setColorMessage('danger');
      setShowToast(true);
      setTimeout(()=>{
        setShowToast(false);
      }, 5000)
      
      } else if (Form.bedrooms.length === 0) {
        setHeaderMessage('Warning');
        setMessage('Enter the Bedrooms !');
        setColorMessage('danger');
        setShowToast(true);
        setTimeout(()=>{
          setShowToast(false);
        }, 5000)
      
      } else if (Form.dateTimeAdding.length === 0) {
        setHeaderMessage('Warning');
        setMessage('Select Date of the added property !');
        setColorMessage('danger');
        setShowToast(true);
        setTimeout(()=>{
          setShowToast(false); 
        }, 5000)
        
        }  else if (Form.monthlyRentPrice.length === 0) {
          setHeaderMessage('Warning');
          setMessage('Enter the Monthly rent price!');
          setColorMessage('danger');
          setShowToast(true);
          setTimeout(()=>{
            setShowToast(false);
          }, 5000)
        
        } else if (Form.nameReporter.length === 0) {
          setHeaderMessage('Warning');
          setMessage(`Enter Reporter's Name !`);
          setColorMessage('danger');
          setShowToast(true);
          setTimeout(()=>{
            setShowToast(false);
          }, 5000)
        
        } else {
          setHeaderMessage('Success');
          setMessage('Successful submission');
          setColorMessage('success');
          setShowToast(true);
          setTimeout(()=>{
            setShowToast(false);
          }, 5000)
        
        }
        
        };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Validation App</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div className="ion-padding">
          {/* Start Select Property type */}
          <IonItem>
            <IonLabel position="stacked">Property type</IonLabel>
            <IonSelect 
              value={propertyType} 
              onIonChange={event => setPropertyType(event.detail.value)} 
              placeholder="Select property type"
            >
              <IonSelectOption value="Flat">Flat</IonSelectOption>
              <IonSelectOption value="House">House</IonSelectOption>
              <IonSelectOption value="Bungalow">Bungalow</IonSelectOption>
            </IonSelect>
          </IonItem>
          {/* End Select Property type */}

          {/* Start Input Number Bedrooms */}
          <IonItem>
            <IonLabel position="stacked">Bedrooms</IonLabel>
            <IonInput type='number'
              onIonChange={event => setBedrooms(event.detail.value!)} 
              placeholder="Enter the number of bedrooms"
            ></IonInput>
          </IonItem>
          {/* End Input Number Bedrooms */}

          {/* Start Date and time of adding the Property */}
          <IonItem>
            <IonLabel position="stacked">
              Date and time of adding the Property
            </IonLabel>
            <IonDatetime 
              onIonChange={event => setDateTimeAdding(event.detail.value!)} 
              display-format="YYYY/MM/DD" 
              placeholder="Select date and time"
            ></IonDatetime>
          </IonItem>
          {/* End Date and time of adding the Property */}

          {/* Start Monthly rent price */}
          <IonItem>
            <IonLabel position="stacked">Monthly rent price</IonLabel>
            <IonInput type='number'
              onIonChange={event => setMonthlyRentPrice(event.detail.value!)} 
              placeholder="Enter monthly rent price"
            ></IonInput>
          </IonItem>
          {/* End Monthly rent price */}

          {/* Start furniture types */}
          <IonItem>
            <IonLabel position="stacked">Furniture types</IonLabel>
            <IonRadioGroup onIonChange={e => setFurnitureTypes(e.detail.value)} style={{ marginTop: '5px' }}>
              <IonItem>
                <IonLabel><small>Furnished</small></IonLabel>
                <IonRadio slot="start" value="Furnished"></IonRadio>
              </IonItem>
              <IonItem>
                <IonLabel><small>Unfurnished</small></IonLabel>
                <IonRadio slot="start" value="Unfurnished"></IonRadio>
              </IonItem>
              <IonItem>
                <IonLabel><small>Part Furnished</small></IonLabel>
                <IonRadio slot="start" value="PartFurnished"></IonRadio>
              </IonItem>
            </IonRadioGroup>
          </IonItem>
          {/* End furniture types */}

          {/* Start Notes */}
          <IonItem>
            <IonLabel position="stacked">Notes</IonLabel>
            <IonTextarea
              onIonChange={event => setNotes(event.detail.value!)}
              placeholder="Enter Notes"
            >
            </IonTextarea>
          </IonItem>
          {/* End Notes */}

          {/* Start Name of the reporter */}
          <IonItem>
            <IonLabel position="stacked">Name of the reporter</IonLabel>
            <IonInput 
              onIonChange={event => setNameReporter(event.detail.value!)} 
              placeholder="Enter name of the reporter"
            ></IonInput>
          </IonItem>
          {/* End Name of the reporter */}

          {/* Start Button Submit */}
          <IonButton expand="block" onClick={handleSubmit}>
            <IonIcon slot="icon-only" icon={add}></IonIcon>Submit</IonButton>
          {/* End Button Submit */}

          {/* Start Toast */}
          <IonToast 
            isOpen={showToast} 
            header={headerMessage} 
            message={message} 
            color={colorMessage} 
            position="top"
          ></IonToast>
          {/* End Toast */}
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Home;
