import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonText, IonItem, IonButton, IonIcon} from '@ionic/react';
import ReactAudioPlayer from 'react-audio-player';
import { pause, play } from 'ionicons/icons';

import './Home.css';

const Home: React.FC = () => {
  let musicPlayer: ReactAudioPlayer | null;

  return (
    <IonPage>
      {/* Header Page  */}
      <IonHeader>
        <IonToolbar>
          <IonTitle>Notification App</IonTitle>
        </IonToolbar>
      </IonHeader>

      {/* Main Page */}
      <IonContent fullscreen>
        
        {/* Music */}
        <IonItem>
          <IonText>
            <h4>Music</h4>
          </IonText>
        </IonItem>
        <IonItem>
          <IonButton onClick={() => musicPlayer?.audioEl.current?.play()}>
          <IonIcon slot="icon-only" icon={play}></IonIcon>Play music</IonButton>
          <IonButton onClick={() => musicPlayer?.audioEl.current?.pause()}>
          <IonIcon slot="icon-only" icon={pause}></IonIcon>Pause music</IonButton>
          <ReactAudioPlayer
            ref={(element) => { musicPlayer = element; }}
            src="./assets/music.mp3"
          />
        </IonItem>
        
        {/* Ring the bell */}
        <IonItem>
          <IonText>
            <h4>Ring a bell</h4>
          </IonText>
        </IonItem>
        <IonItem>
          <IonButton onClick={() => {musicPlayer?.audioEl.current?.play();
            navigator.vibrate(4000); setTimeout(()=>{
              musicPlayer?.audioEl.current?.pause()
            }, 4000);
          }}>Ring a bell</IonButton>
        </IonItem>

        {/* Vibrate */}
        <IonItem>
          <IonText>
            <h4>Vibrate</h4>
          </IonText>
        </IonItem>
        <IonItem>
          <IonButton onClick={() => navigator.vibrate(2000)}>Vibrate</IonButton>
        </IonItem>
      </IonContent>
    </IonPage>
  );
};

export default Home;
